"""
Stars Shop Bot - Admin Handlers
Professional Version - 100% Working
SUPPORTS MULTIPLE ADMINS
"""
import logging
import time
from telebot import TeleBot, types

logger = logging.getLogger(__name__)

admin_states = {}


def is_admin(user_id: int) -> bool:
    """Check if user is admin - SUPPORTS MULTIPLE ADMINS"""
    from config import Config
    
    # Get admin IDs (supports both single and multiple admins)
    admin_ids = Config.ADMIN_ID
    
    # Convert to list if single admin
    if isinstance(admin_ids, int):
        admin_ids = [admin_ids]
    elif isinstance(admin_ids, str):
        # Parse comma-separated string
        admin_ids = [int(x.strip()) for x in admin_ids.split(',') if x.strip().isdigit()]
    
    return user_id in admin_ids


def register_admin_handlers(bot: TeleBot):
    """Register all admin handlers"""
    
    @bot.message_handler(func=lambda m: m.text == "⚙️ Admin panel" and is_admin(m.from_user.id))
    def admin_panel_handler(message: types.Message):
        """Admin panel main"""
        try:
            from database import get_stats
            from keyboards import admin_main_kb
            from utils import format_money
            
            stats = get_stats()
            
            text = (
                "⚙️ ADMIN PANEL\n\n"
                f"👥 Foydalanuvchilar: {stats.get('total_users', 0)}\n"
                f"👑 VIP: {stats.get('vip_users', 0)}\n"
                f"📦 Jami buyurtmalar: {stats.get('total_orders', 0)}\n"
                f"⏳ Kutilmoqda: {stats.get('pending_orders', 0)}\n"
                f"💸 To'langan: {stats.get('paid_orders', 0)}\n"
                f"💰 Jami daromad: {format_money(stats.get('total_revenue', 0))} so'm\n\n"
                "Kerakli bo'limni tanlang:"
            )
            
            bot.send_message(
                message.chat.id,
                text,
                reply_markup=admin_main_kb()
            )
        except Exception as e:
            logger.error(f"admin_panel error: {e}", exc_info=True)
            bot.reply_to(message, "❗ Xatolik!")
    
    
    @bot.message_handler(commands=['stats'])
    def stats_command(message: types.Message):
        """Statistics"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            from database import get_stats, get_settings
            from utils import generate_stats_text
            
            stats = get_stats()
            settings = get_settings()
            text = generate_stats_text(stats, settings)
            
            bot.send_message(message.chat.id, text)
        except Exception as e:
            logger.error(f"stats error: {e}")
            bot.reply_to(message, "❗ Xatolik!")
    
    
    @bot.message_handler(commands=['confirm'])
    def confirm_order_command(message: types.Message):
        """Confirm order"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            from database import get_order, get_settings
            from utils import format_money
            from services.order_service import OrderService
            
            try:
                order_id = int(message.text.split()[1])
            except:
                bot.reply_to(message, "❗ Format: /confirm <order_id>")
                return
            
            settings = get_settings()
            success, msg = OrderService.confirm_order(order_id, settings)
            
            if success:
                order = get_order(order_id)
                bot.reply_to(message, f"✅ {msg}")
                
                try:
                    user_text = (
                        f"✅ Buyurtmangiz tasdiqlandi!\n\n"
                        f"Buyurtma #{order_id}\n"
                        f"Summa: {format_money(order['total_sum'])} so'm\n\n"
                        f"Rahmat! 🎉"
                    )
                    bot.send_message(order['user_id'], user_text)
                except Exception as e:
                    logger.error(f"User notification error: {e}")
            else:
                bot.reply_to(message, f"❌ {msg}")
        
        except Exception as e:
            logger.error(f"confirm error: {e}", exc_info=True)
            bot.reply_to(message, "❗ Xatolik!")
    
    
    @bot.message_handler(commands=['reject'])
    def reject_order_command(message: types.Message):
        """Reject order"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            from database import get_order
            from services.order_service import OrderService
            
            try:
                parts = message.text.split(maxsplit=2)
                order_id = int(parts[1])
                reason = parts[2] if len(parts) > 2 else "Sabab ko'rsatilmagan"
            except:
                bot.reply_to(message, "❗ Format: /reject <order_id> <sabab>")
                return
            
            success, msg = OrderService.reject_order(order_id, reason)
            
            if success:
                order = get_order(order_id)
                bot.reply_to(message, f"✅ {msg}")
                
                try:
                    user_text = (
                        f"❌ Buyurtmangiz rad etildi\n\n"
                        f"Buyurtma #{order_id}\n"
                        f"Sabab: {reason}\n\n"
                        "Admin bilan bog'laning."
                    )
                    bot.send_message(order['user_id'], user_text)
                except Exception as e:
                    logger.error(f"User notification error: {e}")
            else:
                bot.reply_to(message, f"❌ {msg}")
        
        except Exception as e:
            logger.error(f"reject error: {e}", exc_info=True)
            bot.reply_to(message, "❗ Xatolik!")
    
    
    @bot.message_handler(commands=['addstars'])
    def addstars_command(message: types.Message):
        """Add stars to user"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            from database import get_user, update_balance
            from config import Constants
            
            try:
                parts = message.text.split()
                user_id = int(parts[1])
                amount = int(parts[2])
            except:
                bot.reply_to(message, "❗ Format: /addstars <user_id> <amount>")
                return
            
            user = get_user(user_id)
            if not user:
                bot.reply_to(message, "❌ Foydalanuvchi topilmadi!")
                return
            
            success = update_balance(
                user_id,
                amount,
                Constants.TRANSACTION_TYPES['ADMIN_ADD'],
                f"Admin tomonidan qo'shildi"
            )
            
            if success:
                new_balance = user['balance'] + amount
                bot.reply_to(message, f"✅ {amount} Stars qo'shildi!\n\nYangi balans: {new_balance} ⭐")
                
                try:
                    bot.send_message(
                        user_id,
                        f"🎁 Sizga {amount} Stars qo'shildi!\n\n"
                        f"Yangi balans: {new_balance} ⭐"
                    )
                except Exception as e:
                    logger.error(f"User notification error: {e}")
            else:
                bot.reply_to(message, "❌ Xatolik!")
        
        except Exception as e:
            logger.error(f"addstars error: {e}", exc_info=True)
            bot.reply_to(message, "❗ Xatolik!")
    
    
    @bot.message_handler(commands=['deductstars'])
    def deductstars_command(message: types.Message):
        """Deduct stars from user"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            from database import get_user, update_balance
            from config import Constants
            
            try:
                parts = message.text.split()
                user_id = int(parts[1])
                amount = int(parts[2])
            except:
                bot.reply_to(message, "❗ Format: /deductstars <user_id> <amount>")
                return
            
            user = get_user(user_id)
            if not user:
                bot.reply_to(message, "❌ Foydalanuvchi topilmadi!")
                return
            
            success = update_balance(
                user_id,
                -amount,
                Constants.TRANSACTION_TYPES['ADMIN_DEDUCT'],
                f"Admin tomonidan yechildi"
            )
            
            if success:
                new_balance = max(0, user['balance'] - amount)
                bot.reply_to(message, f"✅ {amount} Stars yechildi!\n\nYangi balans: {new_balance} ⭐")
                
                try:
                    bot.send_message(
                        user_id,
                        f"⚠️ Balansdan {amount} Stars yechildi.\n\n"
                        f"Yangi balans: {new_balance} ⭐"
                    )
                except Exception as e:
                    logger.error(f"User notification error: {e}")
            else:
                bot.reply_to(message, "❌ Xatolik!")
        
        except Exception as e:
            logger.error(f"deductstars error: {e}", exc_info=True)
            bot.reply_to(message, "❗ Xatolik!")
    
    
    @bot.message_handler(commands=['vipgrant'])
    def vipgrant_command(message: types.Message):
        """Grant VIP to user"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            from services.vip_service import VIPService
            
            try:
                parts = message.text.split()
                user_id = int(parts[1])
                days = int(parts[2])
            except:
                bot.reply_to(message, "❗ Format: /vipgrant <user_id> <days>")
                return
            
            success, msg = VIPService.extend_vip(user_id, days)
            
            if success:
                bot.reply_to(message, f"✅ {msg}")
                
                try:
                    bot.send_message(
                        user_id,
                        f"👑 Sizga VIP status berildi!\n\n"
                        f"Muddat: {days} kun\n"
                        f"Chegirma: 20%\n\n"
                        f"Rahmat! 🎉"
                    )
                except Exception as e:
                    logger.error(f"User notification error: {e}")
            else:
                bot.reply_to(message, f"❌ {msg}")
        
        except Exception as e:
            logger.error(f"vipgrant error: {e}", exc_info=True)
            bot.reply_to(message, "❗ Xatolik!")
    
    
    @bot.message_handler(commands=['viprevoke'])
    def viprevoke_command(message: types.Message):
        """Revoke VIP from user"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            from services.vip_service import VIPService
            
            try:
                user_id = int(message.text.split()[1])
            except:
                bot.reply_to(message, "❗ Format: /viprevoke <user_id>")
                return
            
            success, msg = VIPService.revoke_vip(user_id)
            
            if success:
                bot.reply_to(message, f"✅ {msg}")
                
                try:
                    bot.send_message(user_id, "⚠️ VIP statusingiz bekor qilindi.")
                except Exception as e:
                    logger.error(f"User notification error: {e}")
            else:
                bot.reply_to(message, f"❌ {msg}")
        
        except Exception as e:
            logger.error(f"viprevoke error: {e}", exc_info=True)
            bot.reply_to(message, "❗ Xatolik!")
    
    
    @bot.message_handler(commands=['broadcast'])
    def broadcast_command(message: types.Message):
        """Start broadcast"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            bot.reply_to(
                message,
                "📨 BROADCAST\n\nYubormoqchi bo'lgan xabaringizni yozing:"
            )
            
            admin_states[message.from_user.id] = {'action': 'broadcast_message'}
        
        except Exception as e:
            logger.error(f"broadcast error: {e}")
    
    
    @bot.message_handler(commands=['reply'])
    def reply_ticket_command(message: types.Message):
        """Reply to support ticket"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            from database import add_ticket_message, get_db
            
            try:
                parts = message.text.split(maxsplit=2)
                ticket_id = int(parts[1])
                reply_text = parts[2]
            except:
                bot.reply_to(message, "❗ Format: /reply <ticket_id> <javob>")
                return
            
            success = add_ticket_message(
                ticket_id,
                message.from_user.id,
                reply_text,
                is_admin=True
            )
            
            if success:
                bot.reply_to(message, "✅ Javob yuborildi!")
                
                try:
                    with get_db() as conn:
                        c = conn.cursor()
                        c.execute("SELECT user_id FROM support_tickets WHERE id=?", (ticket_id,))
                        row = c.fetchone()
                        if row:
                            user_id = row['user_id']
                            bot.send_message(
                                user_id,
                                f"💬 Admin javobi:\n\n{reply_text}"
                            )
                except Exception as e:
                    logger.error(f"User notification error: {e}")
            else:
                bot.reply_to(message, "❌ Xatolik!")
        
        except Exception as e:
            logger.error(f"reply error: {e}", exc_info=True)
            bot.reply_to(message, "❗ Xatolik!")
    
    
    @bot.message_handler(commands=['admins'])
    def admins_command(message: types.Message):
        """List all admins"""
        try:
            if not is_admin(message.from_user.id):
                return
            
            from config import Config
            
            admin_ids = Config.ADMIN_ID
            if isinstance(admin_ids, int):
                admin_ids = [admin_ids]
            elif isinstance(admin_ids, str):
                admin_ids = [int(x.strip()) for x in admin_ids.split(',') if x.strip().isdigit()]
            
            text = "👨‍💼 ADMIN RO'YXATI:\n\n"
            for admin_id in admin_ids:
                text += f"• ID: {admin_id}\n"
            
            bot.send_message(message.chat.id, text)
        
        except Exception as e:
            logger.error(f"admins error: {e}")
    
    
    @bot.callback_query_handler(func=lambda call: call.data.startswith('admin:') and is_admin(call.from_user.id))
    def admin_callback(call: types.CallbackQuery):
        """Admin panel callbacks"""
        try:
            from database import get_stats, get_settings, get_all_users
            from keyboards import admin_main_kb, admin_orders_kb
            from utils import generate_stats_text, format_money
            
            action = call.data.split(':')[1]
            
            if action == 'stats':
                stats = get_stats()
                settings = get_settings()
                text = generate_stats_text(stats, settings)
                bot.edit_message_text(
                    text,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=admin_main_kb()
                )
            
            elif action == 'orders':
                text = "📦 BUYURTMALAR\n\nStatus bo'yicha tanlang:"
                bot.edit_message_text(
                    text,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=admin_orders_kb()
                )
            
            elif action == 'users':
                users = get_all_users(limit=20)
                text = f"👥 FOYDALANUVCHILAR (Jami: {len(users)})\n\n"
                for user in users[:10]:
                    vip = "👑" if user.get('is_vip') else ""
                    username = f"@{user['username']}" if user.get('username') else user['full_name']
                    text += f"{vip} {username} - {user['balance']}⭐\n"
                
                bot.edit_message_text(
                    text,
                    call.message.chat.id,
                    call.message.message_id
                )
            
            elif action == 'back':
                stats = get_stats()
                text = (
                    "⚙️ ADMIN PANEL\n\n"
                    f"👥 Foydalanuvchilar: {stats.get('total_users', 0)}\n"
                    f"👑 VIP: {stats.get('vip_users', 0)}\n"
                    f"📦 Jami buyurtmalar: {stats.get('total_orders', 0)}\n"
                    f"⏳ Kutilmoqda: {stats.get('pending_orders', 0)}\n"
                    f"💸 To'langan: {stats.get('paid_orders', 0)}\n"
                    f"💰 Jami daromad: {format_money(stats.get('total_revenue', 0))} so'm\n\n"
                    "Kerakli bo'limni tanlang:"
                )
                bot.edit_message_text(
                    text,
                    call.message.chat.id,
                    call.message.message_id,
                    reply_markup=admin_main_kb()
                )
        
        except Exception as e:
            logger.error(f"admin_callback error: {e}", exc_info=True)
            bot.answer_callback_query(call.id, "❗ Xatolik!")
    
    
    @bot.callback_query_handler(func=lambda call: call.data.startswith('orders:') and is_admin(call.from_user.id))
    def admin_orders_callback(call: types.CallbackQuery):
        """Admin orders callbacks"""
        try:
            from database import get_orders_by_status, get_stats
            from keyboards import admin_orders_kb
            from utils import format_money
            
            status = call.data.split(':')[1]
            
            if status in ['pending', 'paid', 'confirmed', 'cancelled']:
                orders = get_orders_by_status(status, limit=10)
                if orders:
                    text = f"📦 {status.upper()} BUYURTMALAR\n\n"
                    for order in orders[:5]:
                        text += f"#{order['id']} - {format_money(order['total_sum'])} so'm\n"
                        text += f"User ID: {order['user_id']}\n\n"
                else:
                    text = f"📦 {status.upper()} buyurtmalar yo'q."
            else:
                stats = get_stats()
                text = f"📦 BARCHA BUYURTMALAR\n\nJami: {stats.get('total_orders', 0)}"
            
            bot.edit_message_text(
                text,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=admin_orders_kb()
            )
        
        except Exception as e:
            logger.error(f"admin_orders_callback error: {e}", exc_info=True)
    
    
    @bot.message_handler(func=lambda m: is_admin(m.from_user.id) and m.from_user.id in admin_states)
    def admin_text_handler(message: types.Message):
        """Admin text handler"""
        try:
            from database import get_all_users
            
            state = admin_states.get(message.from_user.id, {})
            action = state.get('action')
            
            if action == 'broadcast_message':
                users = get_all_users()
                sent = 0
                failed = 0
                
                progress_msg = bot.reply_to(message, f"📨 Xabar yuborilmoqda... 0/{len(users)}")
                
                for i, user in enumerate(users):
                    try:
                        bot.send_message(user['user_id'], message.text)
                        sent += 1
                        time.sleep(0.05)
                        
                        if (i + 1) % 20 == 0:
                            try:
                                bot.edit_message_text(
                                    f"📨 Xabar yuborilmoqda... {i + 1}/{len(users)}",
                                    message.chat.id,
                                    progress_msg.message_id
                                )
                            except:
                                pass
                    except Exception as e:
                        logger.error(f"Broadcast user {user['user_id']}: {e}")
                        failed += 1
                
                final_text = (
                    f"✅ Broadcast tugadi!\n\n"
                    f"Yuborildi: {sent}\n"
                    f"Xato: {failed}"
                )
                bot.send_message(message.chat.id, final_text)
                
                del admin_states[message.from_user.id]
        
        except Exception as e:
            logger.error(f"admin_text_handler error: {e}", exc_info=True)
    
    logger.info("✅ Admin handlers registered successfully")
